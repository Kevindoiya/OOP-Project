import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
public class LaptopEntry {
	private String brand;
	private String name;
	private int repaircost;      // Cost of repairs
    private int customerpayment; // Payment received from the customer
    
    public LaptopEntry(String brand, String name, int repaircost, int customerpayment) {
        this.brand = brand;
        this.name = name;
        this.repaircost = repaircost;
        this.customerpayment = customerpayment;
    }
	public LaptopEntry() {
		
	}
	public String getbrand() {
		return brand;
	}
	public void setbrand(String brand) {
		this.brand = brand;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public int getrepaircost() {
        return repaircost;
    }

    public void setrepaircost(int repaircost) {
        this.repaircost = repaircost;
    }

    public int getcustomerpayment() {
        return customerpayment;
    }

    public void setcustomerpayment(int customerpayment) {
        this.customerpayment = customerpayment;
    }
	

}

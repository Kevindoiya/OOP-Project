import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
public class LaptopDirectory {
	private LaptopEntry[] book;	
	private int count;
		public LaptopDirectory() {	
			book = new LaptopEntry[10];		
			count = 0;	
		}
		
		
		public boolean add(LaptopEntry e) {
			if (count == 10) {
				return false;		
			}
			else {
				book[count] = e;
				count++;
				return true;
			}
		}
		public void printBook() {
			System.out.println("Here are all the current entries: ");
			for(int i = 0; i<count;i++) {
				if(book[i]==null) {
					continue;
				}
				System.out.println(i+"."+"  "+book[i].getbrand()+"  "+ book[i].getname()+"  "+book[i].getrepaircost()+"  "+book[i].getcustomerpayment());
			}
			
		}
		public void changebrand(int index, String newbrand) {
		    book[index].setbrand(newbrand);
		 }
		public void changename(int index, String newname) {
		    book[index].setname(newname);
		}
		public void changerepaircost(int index, int newrepaircost) {
		    book[index].setrepaircost(newrepaircost);    
		}
		public void changecustomerpayment(int index, int newcustomerpayment) {
		    book[index].setcustomerpayment(newcustomerpayment);
		}
		public LaptopEntry indexer(int z) {
			return book[z];
		}
		public void change(int index, LaptopEntry entry) {
			book[index] = entry;
		}
		public void printFinancialReport() {
		        int totalSpent = 0;
		        int totalEarned = 0;
		        for (int i = 0; i < count; i++) {
		            if (book[i] != null) {
		                totalSpent += book[i].getrepaircost();
		                totalEarned += book[i].getcustomerpayment();
		            }
		        }
		        int totalProfit = totalEarned - totalSpent;
		        System.out.println("Total Spent on Repairs: $" + totalSpent);
		        System.out.println("Total Earned from Customers: $" + totalEarned);
		        System.out.println("Total Profit: $" + totalProfit);
		    }
		public static void menu(){
			System.out.println("Here are your options:");
		    System.out.println("1. Add a Laptop");
		    System.out.println("2. Delete a Laptop");
		    System.out.println("3. Edit a Laptop ");
		    System.out.println("4. Display all Laptops and all their information ");
		    System.out.println("5. Search all Laptops that their repair cost is above a certain value");
		    System.out.println("6. Print Financial Report ");
		    System.out.println("7. Exit");    		
		}
		public static void main(String[] args) throws IOException{
			Scanner input = new Scanner(System.in);
			LaptopDirectory book1 = new LaptopDirectory();
			menu();	
			int answer = input.nextInt();
			String[] brandlist = new String[10];
			String[] namelist = new String [10];
			int[] repaircostlist = new int[10];
			int[] customerpaymentlist = new int [10];
			int index;
			while(answer!=7) {
				if (answer == 1) {								
					System.out.println("What is the brand?");
					String b = input.next();			
					System.out.println("What is the name?");
					String n = input.next();			 
					System.out.println("What is the repair cost?");
					int r = input.nextInt();
					System.out.println("What is the customer payment?");
					int c = input.nextInt();
					LaptopEntry e = new LaptopEntry(b,n,r,c);
					book1.add(e);		
					System.out.println("The entry has been added.");
					
				}
				else if(answer == 2) {		
					   System.out.println("What's the index of the laptop that you want to delete?");
					   int n2 = input.nextInt();				    				    
					   LaptopEntry em = new LaptopEntry();
					   book1.change(n2, em);
					   }  
				else if(answer == 3) {
					System.out.println("What is the index of the laptop you want to edit?");
					int n3 = input.nextInt();
					System.out.println("Which variable you want to change?");
					System.out.println("1. brand?");
					System.out.println("2. name?");
					System.out.println("3. repaircost?");
					System.out.println("4. customerpayment?");
					int j = input.nextInt();
					if(j==1) {
						System.out.println("What do you want to change to?");
						String m1 = input.next();
						book1.indexer(n3).setbrand(m1);
						
					}
					else if(j==2) {
						System.out.println("What do you want to change to?");
						String p1 = input.next();
						book1.indexer(n3).setname(p1);
						
					}
					else if(j==3) {
						System.out.println("What do you want to change to?");
						int s1 = input.nextInt();
						book1.indexer(n3).setrepaircost(s1);				
					}
					else {
						System.out.println("What do you want to change to?");
						int n1 = input.nextInt();
						book1.indexer(n3).setcustomerpayment(n1);
						
					}					
				}	
				else if(answer == 4) {
					book1.printBook();
				}
				else if(answer == 5) {
					System.out.println("Enter a certain price: ");
					int n5 = input.nextInt();
					System.out.println("Search all Laptops that their repair cost is above a certain value");
					for(int k5 = 0; k5<book1.count; k5++) {
						if(book1.indexer(k5).getrepaircost()>n5) {					
							System.out.println(k5+"."+book1.indexer(k5).getbrand()+" "+book1.indexer(k5).getname()+" "+book1.indexer(k5).getrepaircost()+" "+book1.indexer(k5).getcustomerpayment());
						}
					}
				}
				else{
				    book1.printFinancialReport();
				}
				menu();
				answer = input.nextInt();
										
				}
		}
}
				
				
				
				
	
	

	
	

